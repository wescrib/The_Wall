#WILLIAM SCRIBNER
#USING FLASK, THIS IS DESIGNED TO ALLOW USERS TO LOGIN IF THEIR CREDS ARE REGISTERED IN A GIVEN DATABASE, IF NOT THEN THE USERS WILL REGISTER THEIR NAME, EMAIL, AND PASSWORDS ON A WEBPAGE THAT WILL BE INSERTED INTO THE DATABASE. AFTER LOGGING IN THE USERS SHOULD BE ABLE TO MAKE A VERY BASIC POST ON A 'WALL' AND COMMENT ON OTHER POSTS

from flask import Flask, request, redirect, render_template, flash, session
import re
import bcrypt
from mysqlconnection import MySQLConnector

app = Flask(__name__)
mysql = MySQLConnector(app,'wall_db')
app.secret_key="chamber of secrets"

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

@app.route('/')
def index():                        
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    errors=[]
    #FIRST NAME
    if len(request.form['first']) < 1:
		errors.append("First name MUST be completed")
    elif len(request.form['first']) < 2:
        errors.append("First name MUST be longer than 1 letters.")
        print "PASSED NAME"
    #LAST NAME
	if len(request.form['last']) < 1:
		errors.append("Last name MUST be completed")
    elif len(request.form['last']) < 2:
        errors.append("Last name MUST be longer than 1 letters.")

    #INITIAL PASSWORD SET
    if len(request.form['password']) < 2:
        errors.append("Password is blank")
    
    #PASSWORD MATCH?
    if len(request.form['confirmPassword']) < 1:
        errors.append("Confirm password is blank")
    elif request.form['confirmPassword'] != request.form['password']:
        errors.append("Passwords do not match")

    #EMAIL VALIDATION
    if len(request.form['email']) < 1:
        errors.append("Email is blank")
    elif not EMAIL_REGEX.match(request.form['email']):
        errors.append("Invalid Email")

    
    if errors ==[]: #INSIRTING FORM INPUT INTO DATABASE
        query = "INSERT INTO users(first_name, last_name,email,password,created_at, updated_at) VALUES (:first, :last, :email, :password,NOW(),NOW())"

        data = { #CAPTURING WHAT IS IN THE FORM AND MATCHING IT TO THE COLUMN IN THE DATABASE
            'first': request.form['first'],
            'last': request.form['last'],
            'email': request.form['email'],
            'password': bcrypt.hashpw(request.form['password'].encode(), bcrypt.gensalt())
        }

        #CAPTURING USER ID AND THROWING IT IN A SESSION SO THE USER DOESNT GET KICKED OUT
        user_id = mysql.query_db(query, data)
        session["user_id"] = user_id
        session["user_name"] = request.form["first"]
        print "MADE IT TO RETURN /wall"
        return redirect('/wall') #if no errors, the user will be redirected to the success page

    for error in errors:
        flash(error)
        print "nope"

    return redirect('/') #if errors, then the page will redirect to the root with the errors that need fixing
#____________________________________________________

@app.route('/login', methods=["POST"])
def login():
    errors = []

    if len(request.form['email']) < 1:
        errors.append("Invalid email")
    elif not EMAIL_REGEX.match(request.form['email']):
        errors.append("Invalid Email")

    #find clarification as to what is going on right here
    query = "SELECT * FROM users where email = '{}'".format(request.form['email'])
    resultSet = mysql.query_db(query) #sticking form input into a var and running it against emails in the db?

    if len(resultSet) < 1:
        errors.append("The email is not on record")
    else:
        if bcrypt.checkpw(request.form['password'].encode(),resultSet[0]['password'].encode()):#running input password against password on record
            session['user_id'] = resultSet[0]['id']
            session['user_name'] = resultSet[0]['first_name']
            return redirect("/wall")
        else:
            errors.append("Password incorrect")  
    for error in errors:
        flash (error)
    return redirect('/') #REDIRECT BACK TO INDEX IF LOGIN ERROR
#__________________________________________________
@app.route("/wall")
def wall(): 
    if "user_id" not in session: 
        flash ('You must login or register first.')
        return redirect('/')
    query = "SELECT * FROM messages"
    messages = mysql.query_db(query)
    return render_template('wall.html')

#__________________________________________________

@app.route("/messages", methods=["POST"])
def message():
    query = "INSERT INTO messages(users_id, message, created_at, updated_at) VALUES(:user_id, :message, NOW(), NOW())" # insert into table name. inside (column names)
    data = {
        'user_id': session['user_id'], 
        'message': request.form['message'],
            
    }
    mysql.query_db(query, data)
    return redirect('/success')
#____________________________________________________________________________________________________________________________________
@app.route('/success')
def success():
    print 'you made it'
    query = "SELECT message, messages.id, first_name FROM messages JOIN users ON messages.users_id = users.id" #the name of the TABLE
    messages = mysql.query_db(query)
    commentQuery = "SELECT comment, first_name, messages_id FROM comments JOIN users on comments.users_id = users.id" #QUERYING RELEVANT DATA FROM COMMENT TABLE SO COMMENTS WILL BE DISPLAYED ON /SUCCESS ROUTE
    comments = mysql.query_db(commentQuery)
    print "comenntin"
    return render_template('posts.html', comment=comments,message=messages)

#___________________________________________________________________________________________________________________________________

@app.route ('/comment', methods=["POST"])
def comment():

    print request.form['messages_id']

    query = "INSERT INTO comments (comment, created_at, updated_at, users_id, messages_id) VALUES (:comment, NOW(), NOW(), :user_id, :messages_id)" # insert into table name. inside (column names)
    data = {
        'user_id': session['user_id'], 
        'comment': request.form['comment'],
        'messages_id': request.form['messages_id']
    }
    
    mysql.query_db(query, data)
    return redirect('/success')

#___________________________________________________________________________________________________________________________________

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


app.run(debug=True)